// Project URL و Publishable key أو anon public key فقط.
// لا تضع service_role أو كلمة مرور قاعدة البيانات هنا.
window.SUPABASE_CONFIG={url:"https://YOUR-PROJECT-REF.supabase.co",key:"YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY"};